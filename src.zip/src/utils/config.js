export const config = {
  Api_Url: 'https://api.beontime.io',
};
