export const config = {
  Api_Url: 'http://51.68.139.99:3000',
};
