import React from 'react';
import {Block, Text} from '../../components';

const Notifications = () => {
  return (
    <Block primary center middle>
      <Text>Coming Soon</Text>
    </Block>
  );
};

export default Notifications;
